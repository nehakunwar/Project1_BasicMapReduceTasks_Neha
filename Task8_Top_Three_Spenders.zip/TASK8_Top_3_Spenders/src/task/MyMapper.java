package task;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MyMapper extends Mapper<LongWritable,Text,Text,DoubleWritable> {
	HashMap<String, String> hm= new HashMap<>();
	HashMap<String, Double> hm2= new HashMap<>();
	//TreeMap<Double,String> tm=new TreeMap<>();
    public void setup(Context context) throws IOException{
   	 Path[] allFiles=DistributedCache.getLocalCacheFiles(context.getConfiguration());
	 
   	 for(Path eachFile:allFiles){
   		if(eachFile.getName().contains("Customer")){
   		 BufferedReader br=new BufferedReader(new FileReader(eachFile.toString()));
   		 
   		 String line=null;
   		 while((line=br.readLine())!=null){
   			 String[] arr=line.split(",");
   			 String id=arr[0];
   			 String name=arr[1];
   			 hm.put(id, name);
   		 }
   		 br.close();
   		}
   		if(eachFile.getName().contains("Transactional")){
      		 BufferedReader br=new BufferedReader(new FileReader(eachFile.toString()));
      		 
      		 String line=null;
      		 while((line=br.readLine())!=null){
      			String eachVal[] = line.split(",");
      			String id=eachVal[2];
      			double amt= Double.parseDouble(eachVal[3]);
      			String pro = hm.get(id);
      			if(pro!=null){
      			if (hm2.containsKey(pro)){
                   double tempamt=hm2.get(pro);
      			    hm2.put(pro,tempamt+amt);
      			}else{
      				hm2.put(pro, amt);
      			}
      			}
      		 }
      		 br.close();
      		}
   				
   	 }

}
    
 TreeMap<Double,String> tm=new TreeMap<Double,String>();  
 public void cleanup(Context context) throws IOException, InterruptedException{
	// double max=0d;
     //String pro="neo";
     Set<Map.Entry<String,Double>> set=hm2.entrySet();
     
     for(Entry<String, Double> en:set){
  	    /*if(max<en.getValue()){
  	        max=en.getValue();
  	        pro=en.getKey();
  	    }*/
    	tm.put(en.getValue(), en.getKey());
     }
     
     for(int i=0;i<3;i++){
    	 Entry<Double,String> en=tm.lastEntry();
    	 context.write(new Text(en.getValue()), new DoubleWritable(en.getKey()));
    	 tm.remove(en.getKey());
     }
    // context.write(new Text(pro), new DoubleWritable(max));
 }

public void map(LongWritable mInpKey, Text mInpVal, Context c) throws IOException, InterruptedException{
	       /*double max=0d;
	       String pro=null;
           Set<Map.Entry<String,String>> set=hm.entrySet();
           
           for(Map.Entry<String,String> en:set){
        	    if(max<Double.parseDouble(en.getValue())){
        	        max=Double.parseDouble(en.getValue());
        	        pro=en.getKey();
        	    }
           }*/	
	} 
}